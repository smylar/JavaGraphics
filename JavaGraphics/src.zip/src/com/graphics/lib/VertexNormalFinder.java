package com.graphics.lib;

@FunctionalInterface
public interface VertexNormalFinder {
	public Vector getVertexNormal(Point p, Facet f);
}
