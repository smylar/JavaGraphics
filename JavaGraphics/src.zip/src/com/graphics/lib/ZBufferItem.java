package com.graphics.lib;

import java.awt.Color;
import java.util.TreeMap;

public class ZBufferItem
{
	//private double zValue = -1;
	//private Color colour;
	private TreeMap<Integer, Color> items = new TreeMap<Integer, Color>();
	
	//public ZBufferItem(){}
	//public ZBufferItem(double zValue)
	//{
	//	this.zValue = zValue;
	//}
	
	//double getzValue() {
	//	return zValue;
	//}
	//Color getColourOld() {
	//	return this.colour;
	//}
	
	Color getColour() {
		//return colour;
		int red = 0;
		int green = 0;
		int blue = 0;
		int alpha = 0;
		for (Color c : items.values()){
			if (c.getAlpha() > alpha) alpha = c.getAlpha();
			red += ((double)c.getRed() / 255) * c.getAlpha();
			blue += ((double)c.getBlue() / 255) * c.getAlpha();
			green += ((double)c.getGreen() / 255) * c.getAlpha();
			if (alpha == 255) break;
		}
		
		if (red > 255) red = 255;
		if (green > 255) green = 255;
		if (blue > 255) blue = 255;
		return new Color(red, green, blue, alpha);
	}
	
	//void setColour(Color colour) {
	//	this.colour = colour;
	//}
	
	public void add(int z, Color colour)
	{
		items.put(z, colour);			
	}
			
}
