package com.graphics.lib;

@FunctionalInterface
public interface PointFinder {
	public Point find();
}
