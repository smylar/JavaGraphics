package com.graphics.lib.transform;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

import com.graphics.lib.Point;

public class SequenceTransform extends Transform {

	private List<Transform> sequence = new ArrayList<Transform>();
	private int cnt = 0;
	
	public void addTransform(Transform t)
	{
		sequence.add(t);
	}

	@Override
	public boolean isCompleteSpecific() {
		return cnt >= sequence.size();
	}

	@Override
	public void afterTransform() {
		this.sequence.get(this.cnt).afterTransform();
		if (this.cnt < this.sequence.size() && sequence.get(this.cnt).isCompleteSpecific()) this.cnt++;
	}

	@Override
	public Consumer<Point> doTransformSpecific() {
		if (this.cnt >= this.sequence.size() && this.resetAfterComplete)
		{
			this.cnt = 0;
			this.setCompleted(false);
		}
		
		if (this.cnt < this.sequence.size())
		{
			Transform t = this.sequence.get(cnt);
			
			t.beforeTransform();
			return t.doTransformSpecific();
		}
		return (p) -> {return;};
	}
	
}
