package com.graphics.lib.transform;

import com.graphics.lib.camera.Camera;

public interface CameraTransform {
	public void doTransform(Camera c);
}
