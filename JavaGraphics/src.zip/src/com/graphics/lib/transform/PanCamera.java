package com.graphics.lib.transform;

import com.graphics.lib.CanvasObject;
import com.graphics.lib.camera.Camera;

public class PanCamera<T extends Matrix> extends Rotation<T> implements CameraTransform {

	public PanCamera(Class<T> matrix, double angleProgression) {
		super(matrix, angleProgression);
	}

	@Override
	public void doTransform(Camera c) {
		CanvasObject cam = c.getInitialCamera();
		this.beforeTransform();
		cam.getVertexList().stream().forEach(p -> {
			this.doTransformSpecific().accept(p);
		});
		this.afterTransform();
		c.addCameraRotation(cam);
		c.setCameraCanvasObject(cam);
	}

}
