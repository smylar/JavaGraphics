package com.graphics.lib;

@FunctionalInterface
public interface LightIntensityFinder {
	public IntensityComponents getLightIntensity(Point p, boolean isPartOfBacface);
}
