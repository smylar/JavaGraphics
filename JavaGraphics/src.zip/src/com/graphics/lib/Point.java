package com.graphics.lib;

public class Point {
	public double x = 0;
	public double y = 0;
	public double z = 0;
	private Vector normal = new Vector();
	private IntensityComponents lightIntensity;;
	
	public Point(Point p)
	{
		this.x = p.x;
		this.y = p.y;
		this.z = p.z;
	}
	
	public Point(double x, double y, double z)
	{
		this.x = x;
		this.y = y;
		this.z = z;
	}

	public Vector getNormal() {
		return normal;
	}

	public void setNormal(VertexNormalFinder vnFinder, Facet f) {
		this.normal = vnFinder.getVertexNormal(this, f);
	}
	
	public void setNormal(Vector normal) {
		this.normal = normal;
	}
	
	public IntensityComponents getLightIntensity() {
		if (this.lightIntensity == null) return new IntensityComponents();
		return this.lightIntensity;
	}

	public void setLightIntensity(IntensityComponents lightIntensity) {
		this.lightIntensity = lightIntensity;
	}
	
	public void setLightIntensity(LightIntensityFinder liFinder, boolean isPartOfBackface) {
		this.lightIntensity = liFinder.getLightIntensity(this, isPartOfBackface);
	}
	
	public double distanceTo(Point p2)
	{
		double dx = p2.x - x;
		double dy = p2.y - y;
		double dz = p2.z - z;
		
		double adj = Math.sqrt((dx * dx) + (dz * dz));
		return Math.sqrt((dy * dy) + (adj * adj));
	}
	
	public Vector vectorToPoint(Point p2)
	{
		return new Vector(p2.x - this.x, p2.y - this.y, p2.z - this.z);
	}
	
	@Override
	public String toString(){
		return this.x + "," + this.y + "," + this.z;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		long temp;
		temp = Double.doubleToLongBits(x);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		temp = Double.doubleToLongBits(y);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		temp = Double.doubleToLongBits(z);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Point other = (Point) obj;
		if (Double.doubleToLongBits(x) != Double.doubleToLongBits(other.x))
			return false;
		if (Double.doubleToLongBits(y) != Double.doubleToLongBits(other.y))
			return false;
		if (Double.doubleToLongBits(z) != Double.doubleToLongBits(other.z))
			return false;
		return true;
	}
	
	
}
