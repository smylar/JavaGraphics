package com.graphics.lib;

import java.util.stream.Stream;

import com.graphics.lib.Canvas3D;
import com.graphics.lib.camera.Camera;

public class SlaveCanvas3D extends Canvas3D implements CanvasUpdateListener {
	private static final long serialVersionUID = 1L;
	
	Canvas3D parent;
	
	public SlaveCanvas3D(Camera camera, Canvas3D parent)
	{
		super(camera);	
		this.parent = parent;
		parent.addObserver(this);
	}
	
	public void doDraw()
	{
		ZBuffer zBuffer = new ZBuffer();
		zBuffer.setDispHeight(this.getHeight());
		zBuffer.setDispWidth(this.getWidth());

		parent.getShapes().parallelStream().forEach(s -> {
			this.processShape(s, zBuffer);
		});
		this.setzBuffer(zBuffer);
		this.repaint();
	}
	
	private void processShape(CanvasObject obj, ZBuffer zBuf)
	{
		if (obj.isVisible())
		{
			this.getCamera().getView(obj);
			Stream<Facet> facetStream = obj.getFacetList().stream();
			if (!obj.isProcessBackfaces()){
				facetStream = facetStream.filter(GeneralPredicates.isFrontface(this.getCamera()));
			}
			facetStream.filter(GeneralPredicates.isOverHorizon(this.getCamera(), this.getHorizon()).negate()).forEach(f ->{
				zBuf.Add(f, f.getColour() == null ? obj.getColour() : f.getColour(),  obj.getVertexNormalFinder(), parent.getLightIntensityFinder(), GeneralPredicates.isFrontface(this.getCamera()).test(f));
			});
		}
		for (CanvasObject child : obj.getChildren())
		{
			this.processShape(child, zBuf);
		};
	}

	@Override
	public void update(Canvas3D source) {
		this.doDraw();
	}
}
