package com.graphics.lib;

import java.awt.Graphics;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.function.BiConsumer;
import java.util.stream.Stream;

import javax.swing.JPanel;

import com.graphics.lib.camera.Camera;
import com.graphics.lib.transform.Translation;

public class Canvas3D extends JPanel{

	private static final long serialVersionUID = 1L;
	
	private List<CanvasObject> shapes = new ArrayList<CanvasObject>();
	private List<LightSource> lightSources = new ArrayList<LightSource>(); 
	private Camera camera;
	private ZBuffer zBuffer = new ZBuffer();
	private double horizon = 8000;
	private Set<CanvasUpdateListener> slaves = new HashSet<CanvasUpdateListener>();
	private List<BiConsumer<Canvas3D,Graphics>> drawPlugins = new ArrayList<BiConsumer<Canvas3D,Graphics>>();

	public Canvas3D(Camera camera)
	{
		this.camera = camera;	
	}
	
	public void addDrawOperation(BiConsumer<Canvas3D,Graphics> operation){
		drawPlugins.add(operation);
	}
	
	public double getHorizon() {
		return horizon;
	}

	public void setHorizon(double horizon) {
		this.horizon = horizon;
	}

	public void addLightSource(LightSource lightSource) {
		this.lightSources.add(lightSource);
	}

	public void registerObject(CanvasObject obj, Point position)
	{
		this.registerObject(obj, position, false);
	}
	
	public List<CanvasObject> getShapes() {
		return shapes;
	}

	public List<LightSource> getLightSources() {
		return lightSources;
	}

	public Camera getCamera() {
		return camera;
	}

	public void setCamera(Camera camera) {
		this.camera = camera;
	}
	
	public void addObserver(CanvasUpdateListener l){
		this.slaves.add(l);
	}
	
	protected void setzBuffer(ZBuffer zBuffer) {
		this.zBuffer = zBuffer;
	}
	
	@Override
	public void setVisible(boolean flag)
	{
		super.setVisible(flag);
		this.camera.setViewport(this.getWidth(), this.getHeight());
	}

	public synchronized void registerObject(CanvasObject obj, Point position, boolean drawNow)
	{
		if (this.shapes.contains(obj)) return;

		this.shapes.add(obj);
		obj.addTransform(new Translation(position), true);
		if (drawNow)
		{
			this.doDraw();
		}
	}
	
	public synchronized void doDraw()
	{
		ZBuffer zBuffer = new ZBuffer();
		zBuffer.setDispHeight(this.getHeight());
		zBuffer.setDispWidth(this.getWidth());
		this.lightSources.removeIf(l -> l.isDeleted());
		this.shapes.removeIf(s -> s.isDeleted());
		this.camera.doTransforms();
		this.shapes.parallelStream().forEach(s -> {
			this.processShape(s, zBuffer);
		});
		this.zBuffer = zBuffer;
		this.repaint(); this.slaves.forEach(s -> s.update(this));
		/*try {
			SwingUtilities.invokeAndWait(() -> {this.repaint(); this.slaves.forEach(s -> s.update(this));});
		} catch (InvocationTargetException e) {
			e.printStackTrace();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}*/
			
		this.shapes.parallelStream().forEach(s -> {
			s.onDrawComplete();
		});
		
	}
	
	private void processShape(CanvasObject obj, ZBuffer zBuf)
	{
		obj.applyTransforms();
		if (obj.isVisible())
		{
			this.camera.getView(obj);
			Stream<Facet> facetStream = obj.getFacetList().stream();
			if (!obj.isProcessBackfaces()){
				facetStream = facetStream.filter(GeneralPredicates.isFrontface(this.camera));
			}
			facetStream.filter(GeneralPredicates.isOverHorizon(this.camera, this.horizon).negate()).forEach(f ->{
				zBuf.Add(f, f.getColour() == null ? obj.getColour() : f.getColour(),  obj.getVertexNormalFinder(), this.getLightIntensityFinder(), GeneralPredicates.isFrontface(this.camera).test(f));
			});
		}
		for (CanvasObject child : obj.getChildren())
		{
			this.processShape(child, zBuf);
		};
	}
	
	protected LightIntensityFinder getLightIntensityFinder()
	{
		return (p, bf) -> {
			IntensityComponents maxIntensity = new IntensityComponents();
			
			this.lightSources.stream().filter(l -> l.isOn()).forEach(l ->
			{
				double percent = 0;
				Vector lightVector = l.getPosition().vectorToPoint(p).getUnitVector();
				
				double answer = p.getNormal().dotProduct(lightVector);
				
				double deg = Math.toDegrees(Math.acos(answer));
				if (deg > 90 && !bf)
				{			
					percent = (deg-90) / 90;
				}
				else if (bf)
				{
					//light on the rear of the facet for if we are processing backfaces - which implies the rear may be visible
					percent = (90-deg) / 90;
				}
				
				double intensity = l.getIntensityComponents(p).getRed() * percent;
				if (intensity > maxIntensity.getRed()) maxIntensity.setRed(intensity);
				intensity = l.getIntensityComponents(p).getGreen() * percent;
				if (intensity > maxIntensity.getGreen()) maxIntensity.setGreen(intensity);
				intensity = l.getIntensityComponents(p).getBlue() * percent;
				if (intensity > maxIntensity.getBlue()) maxIntensity.setBlue(intensity);
			});
			return maxIntensity;
		};
	}
	
	@Override
	public void paint(Graphics g)
	{
		super.paint(g);

		this.zBuffer.getBuffer().keySet().stream().forEach(x -> {
			Map<Integer, ZBufferItem> item = this.zBuffer.getBuffer().get(x);
			if (item != null){
			for (Entry<Integer, ZBufferItem> entry : item.entrySet())
			{
				g.setColor(entry.getValue().getColour());
				g.drawLine(x,entry.getKey(), x,entry.getKey());
			}
			}
		});
		
		for(BiConsumer<Canvas3D,Graphics> op : drawPlugins){
			op.accept(this,g);
		}
		
	}

}
