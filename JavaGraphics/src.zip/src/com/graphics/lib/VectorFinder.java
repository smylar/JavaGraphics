package com.graphics.lib;

@FunctionalInterface
public interface VectorFinder {
	public Vector getVector();
}
