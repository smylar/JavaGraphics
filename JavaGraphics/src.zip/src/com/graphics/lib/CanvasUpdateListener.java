package com.graphics.lib;

public interface CanvasUpdateListener {
	public void update(Canvas3D source);
}
