package com.graphics.lib;

@FunctionalInterface
public interface Plugin<T,R> {
	public R execute(T obj);
}
