package com.graphics.lib.camera;

import java.util.HashMap;
import java.util.Map;
import java.util.Observable;

import com.graphics.lib.CanvasObject;
import com.graphics.lib.Point;
import com.graphics.lib.Vector;
import com.graphics.lib.WorldCoord;
import com.graphics.lib.transform.*;

public abstract class Camera extends Observable {
	public static final String CAMERA_MOVED = "cameraMoved";
	private Point position = new Point(0,0,0);
	private CanvasObject cameraCanvasObject;
	private Map<String, CameraTransform> transforms = new HashMap<String, CameraTransform>();
	private double xRot = 0;
	private double yRot = 0;
	private double zRot = 0;
	protected double dispwidth = 0;
	protected double dispheight = 0;
	
	
	public Camera(){
		this.setCameraCanvasObject(this.getInitialCamera());
	}
	
	public CanvasObject getInitialCamera()
	{
		CanvasObject cam = new CanvasObject();
		cam.getVertexList().add(new WorldCoord(0,0,1)); //forward
		cam.getVertexList().add(new WorldCoord(0,-1,0)); //up
		cam.getVertexList().add(new WorldCoord(1,0,0)); //right
		return cam;
	}
		
	public void setCameraCanvasObject(CanvasObject cameraCanvasObject) {
		this.cameraCanvasObject = cameraCanvasObject;
		this.setTransforms();
	}
	
	public CameraTransform getTransform(String key) {
		return this.transforms.get(key);
	}
	
	public double getPitch(){
		return Math.toDegrees(Math.asin(this.getForward().y));
	}
	
	public double getBearing(){
		Vector forward = this.getForward();
		double angle = Math.toDegrees(Math.asin(forward.x));
		if (forward.z < 0 && angle < 0) return -180 - angle;
		if (forward.z < 0) return 180 - angle;
		return angle;
	}

	public Vector getForward() {
		Point forward = this.cameraCanvasObject.getVertexList().get(0);
		return new Vector(forward.x, forward.y, forward.z);
	}
	public Vector getUp() {
		Point up = this.cameraCanvasObject.getVertexList().get(1);
		return new Vector(up.x, up.y, up.z);
	}
	public Vector getRight() {
		Point right = this.cameraCanvasObject.getVertexList().get(2);
		return new Vector(right.x, right.y, right.z);
	}
	public Vector getBack() {
		Point forward = this.cameraCanvasObject.getVertexList().get(0);
		return new Vector(-forward.x, -forward.y, -forward.z);
	}
	public Vector getDown() {
		Point up = this.cameraCanvasObject.getVertexList().get(1);
		return new Vector(-up.x, -up.y, -up.z);
	}
	public Vector getLeft() {
		Point right = this.cameraCanvasObject.getVertexList().get(2);
		return new Vector(-right.x, -right.y, -right.z);
	}
	public Point getPosition() {
		return this.position;
	}
	public void setPosition(Point position) {
		this.position = position;
	}
	
	public void setViewport(double height, double width)
	{
		this.dispheight = height;
		this.dispwidth = width;
	}
	
	public synchronized void addTransform(String key, CameraTransform transform)
	{
		this.transforms.put(key, transform);
	}
	
	public synchronized void removeTransform(String key)
	{
		this.transforms.remove(key);
	}
	
	public synchronized void doTransforms()
	{
		if (transforms.size() == 0) return;
		
		for (CameraTransform t : this.transforms.values())
		{
			t.doTransform(this);
		}
		
		this.setChanged();
		this.notifyObservers(CAMERA_MOVED);
	}
	
	public void alignShapeToCamera(CanvasObject obj)
	{
		obj.applyCameraTransform(new Translation(-position.x, -position.y, -position.z));
		this.matchCameraRotation(obj);
		obj.applyCameraTransform(new Translation(position.x, position.y, position.z));
	}
	
	public void matchCameraRotation(CanvasObject obj)
	{
		obj.applyCameraTransform(new Rotation<YRotation>(YRotation.class, -this.yRot));
		obj.applyCameraTransform(new Rotation<XRotation>(XRotation.class, -this.xRot));
		obj.applyCameraTransform(new Rotation<ZRotation>(ZRotation.class, -this.zRot));
	}
	
	public void addCameraRotation(CanvasObject obj)
	{
		obj.addTransform(new Rotation<ZRotation>(ZRotation.class, this.zRot));
		obj.addTransform(new Rotation<XRotation>(XRotation.class, this.xRot));
		obj.addTransform(new Rotation<YRotation>(YRotation.class, this.yRot));
		obj.applyTransforms();
	}
	
	private void setTransforms()
	{
		Vector forwardv = this.getForward();
		Vector upv = this.getUp();
		Vector rightv = this.getRight();
		WorldCoord forward = new WorldCoord(forwardv.x, forwardv.y, forwardv.z);
		WorldCoord up = new WorldCoord(upv.x, upv.y, upv.z);
		WorldCoord right = new WorldCoord(rightv.x, rightv.y, rightv.z);
			
		CanvasObject temp = new CanvasObject();
		temp.getVertexList().add(forward);
		temp.getVertexList().add(up);
		temp.getVertexList().add(right);
		
		this.xRot = 0;
		this.yRot = 0;
		this.zRot = 0;
		
		if (forward.z < 0) 
			this.yRot = 180;
		
		if (forward.z != 0)
			this.yRot += Math.toDegrees(Math.atan(forward.x / forward.z));
		else if (forward.x > 0)
			this.yRot = 90;
		else if (forward.x < 0)
			this.yRot = -90;
			
		temp.addTransform(new Rotation<YRotation>(YRotation.class, -this.yRot), true);
		
		if (forward.z != 0)
			this.xRot += Math.toDegrees(Math.atan(forward.y / forward.z)) * -1;
		else if (forward.y > 0)
			this.xRot = -90;
		else if (forward.y < 0)
			this.xRot = 90;
			
		temp.addTransform(new Rotation<XRotation>(XRotation.class, -xRot), true);
		
		if (up.y > 0) 
			this.zRot = 180;
		
		if (right.x != 0)
			this.zRot += Math.toDegrees(Math.atan(right.y / right.x));
		else if (right.y > 0)
			this.zRot = 90;
		else if (right.y < 0)
			this.zRot = -90;
		
	}
	
	public final void getView(CanvasObject obj){
		this.getViewSpecific(obj);
	}
	
	public abstract void getViewSpecific(CanvasObject obj);
	
}
