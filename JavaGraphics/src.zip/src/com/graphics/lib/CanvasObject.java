package com.graphics.lib;

import java.awt.Color;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Observable;
import java.util.Observer;
import java.util.stream.Collector;

import com.graphics.lib.transform.Transform;
import com.graphics.lib.transform.Translation;

public class CanvasObject extends Observable implements Observer{
	private List<WorldCoord> vertexList = new ArrayList<WorldCoord>();
	private List<Facet> facetList = new ArrayList<Facet>();
	private Color colour = new Color(255, 0, 0);
	private List<Transform> transforms = new ArrayList<Transform>();
	private List<CanvasObject> children = new ArrayList<CanvasObject>();
	private Map<String,Plugin<CanvasObject,?>> plugins = new HashMap<String,Plugin<CanvasObject,?>>();
	private List<String> afterDrawPlugins = new ArrayList<String>();
	private Map<Point, ArrayList<Facet>> vertexFacetMap;
	private boolean processBackfaces = false;
	private boolean isVisible = true;
	private boolean isDeleted = false;
	//TODO - is solid or phased when invisible?
	private boolean deleteAfterTransforms = false;


	public void registerPlugin(String key, Plugin<CanvasObject,?> plugin, boolean doAfterDraw)
	{
		plugins.put(key, plugin);
		if (doAfterDraw) afterDrawPlugins.add(key);
	}
	
	public void removePlugin(String key)
	{
		this.plugins.remove(key);
		this.afterDrawPlugins.remove(key);
	}
	
	public void removePlugins()
	{
		this.plugins.clear();
		this.afterDrawPlugins.clear();
	}
	
	public List<CanvasObject> getChildren() {
		this.children.removeIf(c -> c.isDeleted());
		return children;
	}

	public boolean isVisible() {
		return isVisible;
	}

	public void setVisible(boolean isVisible) {
		this.setChanged();
		this.notifyObservers();
		this.isVisible = isVisible;
	}

	public boolean isDeleted() {
		return isDeleted;
	}

	public void setDeleted(boolean isDeleted) {
		this.isDeleted = isDeleted;
		this.setChanged();
		this.notifyObservers();
	}

	public Color getColour() {
		return colour;
	}

	public void setColour(Color colour) {
		this.colour = colour;
	}
	
	public List<WorldCoord> getVertexList() {
		return vertexList;
	}

	public void setVertexList(List<WorldCoord> vertexList) {
		this.vertexList = vertexList;
	}

	public List<Facet> getFacetList() {
		return facetList;
	}

	public void setFacetList(List<Facet> facetList) {
		this.facetList = facetList;
	}
	
	public boolean isProcessBackfaces() {
		return processBackfaces;
	}

	public void setProcessBackfaces(boolean processBackfaces) {
		this.processBackfaces = processBackfaces;
	}

	public void cancelTransforms()
	{
		this.transforms.forEach(t -> t.cancel());
	}
	
	//public List<Transform> getTransforms()
	//{
	//	return this.transforms;
	//}
	
	public <T> List<T> getTransformsOfType(Class<T> type)
	{

		List<T> mTrans = this.transforms.stream().filter(t -> t.getClass() == type).collect(Collector.of(
				ArrayList::new,
				(trans, orig) -> trans.add(type.cast(orig)),
				(left, right) -> {left.addAll(right); return left;},
				Collector.Characteristics.CONCURRENT
				));

		return mTrans;
	}
	
	public void addTransform(Transform transform)
	{
		this.addTransform(transform, false);
	}
	
	public void addTransform(Transform transform, boolean applyNow)
	{
		transforms.add(transform);
		if (applyNow)this.applyTransforms();
	}
	
	public void applyCameraTransform(Transform transform)
	{
		transform.doTransform(this.vertexList.stream().collect(Collector.of(
				ArrayList::new,
				(trans, world) -> trans.add(world.getTransformed()),
				(left, right) -> {left.addAll(right); return left;},
				Collector.Characteristics.CONCURRENT
				))
		);
	}
	
	public boolean hasTransforms()
	{
		return transforms.size() > 0;
	}
	
	public void applyTransforms()
	{
		if (this.vertexList == null || this.vertexList.size() == 0 || this.isDeleted) return;
		
		this.transforms.stream().filter(t -> !t.isCancelled()).forEach(t ->
		{
			t.doTransform(this.vertexList);
			this.setChanged();
			this.notifyObservers(t);
		});
		
		transforms.removeIf(t -> {
								t.getDependencyList().removeIf(d -> d.isComplete());
								return t.isComplete() && t.getDependencyList().size() == 0;
								});
		if (transforms.size() == 0 && this.deleteAfterTransforms && children.size() == 0) this.setDeleted(true);
	}
	
	public Point getCentre()
	{
		double maxX = this.vertexList.get(0).x;
		double maxY = this.vertexList.get(0).y;
		double maxZ = this.vertexList.get(0).z;
		double minX = this.vertexList.get(0).x;
		double minY = this.vertexList.get(0).y;
		double minZ = this.vertexList.get(0).z;
		for (Point p : this.vertexList)
		{
			if (p.x > maxX) maxX = p.x;
			if (p.x < minX) minX = p.x;
			if (p.y > maxY) maxY = p.y;
			if (p.y < minY) minY = p.y;
			if (p.z > maxZ) maxZ = p.z;
			if (p.z < minZ) minZ = p.z;
		};
		
		return new Point(minX + ((maxX - minX)/2), minY + ((maxY - minY)/2), minZ + ((maxZ - minZ)/2));
	}
	
	public VertexNormalFinder getVertexNormalFinder()
	{
		return (p, f) -> {
			if (this.vertexFacetMap != null){
				List<Facet> facetList = this.vertexFacetMap.get(p);
				if (facetList != null && facetList.size() > 0)
				{	
					Vector normal = new Vector(0,0,0);
					for(Facet facet : facetList){
						normal.addVector(facet.getNormal());
					}
					return normal.getUnitVector(); //could possibly store for reuse between transforms
				}
			}
			
			return f.getNormal();
		};
	}
	
	public void addTransformAboutCentre(Transform...t)
	{
		this.addTransformAboutPoint(() -> this.getCentre(), t);
	}
	
	public void addTransformAboutPoint(Point p, Transform...transform)
	{
		this.addTransformAboutPoint(() -> p, transform);
	}
	
	public void addTransformAboutPoint(PointFinder pFinder, Transform...transform)
	{
		Translation temp = new Translation(){
			@Override
			public void beforeTransform(){
				Point p = pFinder.find();
				transX = -p.x;
				transY = -p.y;
				transZ = -p.z;
			}
		};
		
		Transform temp2 = new Translation(){
			@Override
			public void beforeTransform(){
				transX = -temp.transX;
				transY = -temp.transY;
				transZ = -temp.transZ;
			}
		};
		this.addTransform(temp);
		for (Transform t : transform)
		{
			temp2.addDependency(t);
			temp.addDependency(t);
			this.addTransform(t);
		}
		this.addTransform(temp2);
	}
	
	public void deleteAfterTransforms()
	{
		this.deleteAfterTransforms = true;
	}
	
	public boolean isPointInside(Point p)
	{
		//should do for most simple objects - can override it for something shape specific
		for (Facet f : this.facetList)
		{
			Vector vecPointToFacet = p.vectorToPoint(f.point1).getUnitVector();
			double deg = Math.toDegrees(Math.acos(vecPointToFacet.dotProduct(f.getNormal())));
			if (deg >= 90) return false;
		}
		return true;
		//Sub shapes???
	}
	
	public Object executePlugin(String key)
	{
		if (this.plugins.containsKey(key) && !this.isDeleted)
		{
			return this.plugins.get(key).execute(this);
		}
		return null;
	}
	
	public void onDrawComplete()
	{
		List<String> pluginList = new ArrayList<String>(this.afterDrawPlugins);
		for (String key : pluginList)
		{
			this.executePlugin(key);
		}
		
		List<CanvasObject> children = new ArrayList<CanvasObject>(this.children);
		for (CanvasObject child : children)
		{
			child.onDrawComplete();
		}
	}
	
	protected void UseAveragedNormals(int divergenceLimit)
	{
		//create map for getting all the facets attached to a specific vertex
		this.vertexFacetMap = new HashMap<Point, ArrayList<Facet>>();
		
		for (Facet f : this.facetList)
		{
			this.addPointFacetToMap(f.point1, f);
			this.addPointFacetToMap(f.point2, f);
			this.addPointFacetToMap(f.point3, f);
		}

	 	//remove anything where the facet group is highly divergent (will then use facet normal when shading)
	 	for (List<Facet> facetList : this.vertexFacetMap.values())
	 	{
	 		boolean isDivergent = false;
	 		Vector normal = facetList.get(0).getNormal();

	 		isDivergent = facetList.stream().anyMatch(f -> {
	 			double answer = normal.dotProduct(f.getNormal());
	 			if (Math.toDegrees(Math.acos(answer)) > divergenceLimit) return true;
	 			return false;
	 		});
	 		
	 		if (isDivergent) facetList.clear();
	 	}

	}
	
	private void addPointFacetToMap(Point p, Facet f)
	{
		if (!this.vertexFacetMap.containsKey(p)){
			this.vertexFacetMap.put(p, new ArrayList<Facet>());
		}
		this.vertexFacetMap.get(p).add(f);
	}

	@Override
	public void update(Observable arg0, Object arg1) {
		if (this != arg0 && arg1 instanceof Transform)
		{
			this.vertexList.stream().forEach(p -> {
				((Transform) arg1).doTransformSpecific().accept(p);
			});
		}
		
	}
	
	public void setBaseIntensity(double intensity)
	{
		this.facetList.forEach(f -> {
			f.setBaseIntensity(intensity);
		});
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((colour == null) ? 0 : colour.hashCode());
		result = prime * result
				+ ((facetList == null) ? 0 : facetList.hashCode());
		result = prime * result + (isDeleted ? 1231 : 1237);
		result = prime * result + (isVisible ? 1231 : 1237);
		result = prime * result
				+ ((vertexList == null) ? 0 : vertexList.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CanvasObject other = (CanvasObject) obj;
		if (colour == null) {
			if (other.colour != null)
				return false;
		} else if (!colour.equals(other.colour))
			return false;
		if (facetList == null) {
			if (other.facetList != null)
				return false;
		} else if (!facetList.equals(other.facetList))
			return false;
		if (isDeleted != other.isDeleted)
			return false;
		if (isVisible != other.isVisible)
			return false;
		if (vertexList == null) {
			if (other.vertexList != null)
				return false;
		} else if (!vertexList.equals(other.vertexList))
			return false;
		return true;
	}

	
}
