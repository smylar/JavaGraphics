package com.graphics.tests;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.KeyEvent;
import java.lang.reflect.InvocationTargetException;
import java.util.Date;
import java.util.Set;
import java.util.stream.Collectors;

import javax.swing.JFrame;
import javax.swing.SwingUtilities;

import com.graphics.lib.CameraTiedLightSource;
import com.graphics.lib.Canvas3D;
import com.graphics.lib.CanvasObject;
import com.graphics.lib.LightSource;
import com.graphics.lib.ObjectTiedLightSource;
import com.graphics.lib.Plugin;
import com.graphics.lib.Point;
import com.graphics.lib.SlaveCanvas3D;
import com.graphics.lib.Vector;
import com.graphics.shapes.Cuboid;
import com.graphics.shapes.Sphere;
import com.graphics.lib.camera.CameraControls;
//import com.graphics.lib.camera.FocusPointCamera;
import com.graphics.lib.camera.ViewAngleCamera;
import com.graphics.lib.transform.MovementTransform;
import com.graphics.lib.transform.PanCamera;
import com.graphics.lib.transform.RepeatingTransform;
import com.graphics.lib.transform.Rotation;
import com.graphics.lib.transform.ScaleTransform;
import com.graphics.lib.transform.SequenceTransform;
import com.graphics.lib.transform.Transform;
import com.graphics.lib.transform.Translation;
import com.graphics.lib.transform.XRotation;
import com.graphics.lib.transform.YRotation;
import com.graphics.lib.transform.ZRotation;
import com.graphics.shapes.Torus;

public class GraphicsTest extends JFrame {

	private static final long serialVersionUID = 1L;
	
	private boolean go = true;
	private JFrame slave;
	private Canvas3D canvas;
	private static GraphicsTest gt;

	public static void main (String[] args){
		try {
			SwingUtilities.invokeAndWait(() -> gt = new GraphicsTest());
			gt.drawCycle();
		} catch (InvocationTargetException e) {
			e.printStackTrace();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
	}
	
	public GraphicsTest(){
		super("Graphics Test");
		this.setLayout(new BorderLayout());
		this.setSize(700, 700);
		
		this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
			
		ViewAngleCamera cam = new ViewAngleCamera();
		cam.setPosition(new Point(350, 350, -50));
		//FocusPointCamera cam = new FocusPointCamera();
		//cam.setFocusPoint(new Point(300, 300, 1000));
		Canvas3D cnv = new Canvas3D(cam);
		
		cnv.addDrawOperation(Utils.showMarkers());
		
		LightSource l1 = new LightSource(0,0,-500);
		l1.setColour(new Color(255, 0, 0));
		cnv.addLightSource(l1);
		LightSource l2 = new LightSource(600,500,-100);
		l2.setColour(new Color(0, 255, 0));
		cnv.addLightSource(l2);
		LightSource l3 = new LightSource(400,100,100);
		l3.setColour(new Color(0, 0, 255));
		cnv.addLightSource(l3);
		

		this.add(cnv, BorderLayout.CENTER);
		
		slave = new JFrame("Slave");
		slave.setLayout(new BorderLayout());
		slave.setSize(300, 300);
		slave.setLocation(750, 50);
		ViewAngleCamera slaveCam = new ViewAngleCamera();
		slaveCam.setPosition(new Point(1500, 350, 400));
		slaveCam.addTransform("INIT", new PanCamera<YRotation>(YRotation.class, -90));
		slaveCam.doTransforms();
		SlaveCanvas3D scnv = new SlaveCanvas3D(slaveCam, cnv);
		slave.add(scnv);
		slave.setVisible(true);
		this.setVisible(true);
		
		Torus torus = new Torus(50,50,20);
		torus.setColour(new Color(250, 250, 250));
		cnv.registerObject(torus, new Point(200,200,400), false);
		
		Transform torust1 = new RepeatingTransform<Rotation<?>>(new Rotation<YRotation>(YRotation.class, 3), 60);
		Transform torust2 = new RepeatingTransform<Rotation<?>>(new Rotation<XRotation>(XRotation.class, 3), 60);
		SequenceTransform torust = new SequenceTransform();
		torust.addTransform(torust1);
		torust.addTransform(torust2);
		torus.addTransformAboutCentre(torust);
		
		Cuboid cube = new Cuboid(200,200,200);
		cnv.registerObject(cube, new Point(500,500,450), false);
		Transform cubet2 = new RepeatingTransform<Rotation<?>>(new Rotation<ZRotation>(ZRotation.class, 3), 30);
		cube.addTransformAboutCentre(cubet2);
		
		Transform cubet = new RepeatingTransform<Translation>(new Translation(-5,0,0), (t) -> {
			return cube.getCentre().x <= 200; 
		});
		
		cube.addTransform(cubet);
		
		Sphere sphere = new Sphere(100,15);
		sphere.setColour(new Color(255, 255, 0));
		cnv.registerObject(sphere, new Point(500,200,400), false);
		
		for (int i = 0; i < sphere.getFacetList().size() ; i++)
		{
			if (i % (sphere.getPointsPerCircle()/3) == 1 || i % (sphere.getPointsPerCircle()/3) == 0)
			{
				sphere.getFacetList().get(i).setColour(new Color(150,0,150));
			}
		}
		
		Plugin<Void,Set<CanvasObject>> getObjects = new Plugin<Void,Set<CanvasObject>>(){
			@Override
			public Set<CanvasObject> execute(Void v) {
				return cnv.getShapes().stream().filter(s -> s.isVisible() && !s.isDeleted()).collect(Collectors.toSet());
			}
		};
		
		Plugin<CanvasObject,Void> explode = new Plugin<CanvasObject,Void>(){
			@Override
			public Void execute(CanvasObject obj) {
				Utils.explode(cnv.getLightSources()).execute(obj).forEach(c -> {
					c.registerPlugin(Events.CHECK_COLLISION, Utils.hasCollided(getObjects, Utils.onCollision(), null), true);
				});
				return null;
			}			
		};
		
		Plugin<CanvasObject,Void> bounce = new Plugin<CanvasObject,Void>(){
			@Override
			public Void execute(CanvasObject obj) {
				CanvasObject impactee = Utils.hasCollided(getObjects,null, null).execute(obj);
				if (impactee != null){
					Utils.bounce(impactee).execute(obj);
				}
				return null;
			}			
		};
		
		ScaleTransform st = new ScaleTransform(0.95);
		RepeatingTransform<ScaleTransform> rpt = new RepeatingTransform<ScaleTransform>(st,15){
			@Override
			public void onComplete(){
				st.setScaling(1.05);
			}
		};
		rpt.setResetAfterComplete(true);
		RepeatingTransform<RepeatingTransform<?>> spheret = new RepeatingTransform<RepeatingTransform<?>>(rpt,30){
			@Override
			public void onComplete(){
				//sphere.executePlugin(Events.EXPLODE);
			}
		};
			
		sphere.addTransformAboutCentre(spheret);
		sphere.registerPlugin(Events.EXPLODE, explode, false);
		torus.registerPlugin(Events.EXPLODE, explode, false);
		cube.registerPlugin(Events.EXPLODE, explode, false);
		
		CameraTiedLightSource l4 = new CameraTiedLightSource(cam.getPosition().x, cam.getPosition().y, cam.getPosition().z);
		l4.tieTo(cam);
		l4.setColour(new Color(255, 255, 255));
		cnv.addLightSource(l4);
		
		
		this.addKeyListener(new CameraControls(cam){
			@Override
			public void keyTyped(KeyEvent key) {
				super.keyTyped(key);
				if (key.getKeyChar() == 'l') l4.toggle();
				
				if (key.getKeyChar() == 'f'){
					Sphere proj = new Sphere(18,20);
					proj.setBaseIntensity(1);
					proj.setColour(new Color(0, 255, 0, 80));
					for (int i = 0; i < proj.getFacetList().size() ; i++)
					{
						if (i % (proj.getPointsPerCircle()/3) == 1 || i % (proj.getPointsPerCircle()/3) == 0)
						{
							proj.getFacetList().get(i).setColour(new Color(0,225,100));
						}
					}
					
					Transform projt = new RepeatingTransform<Rotation<?>>(new Rotation<XRotation>(XRotation.class, 20), 80);
					Transform projt2 = new RepeatingTransform<Rotation<?>>(new Rotation<YRotation>(YRotation.class, 8), 80);
					proj.addTransformAboutCentre(projt, projt2);
					proj.deleteAfterTransforms();
					proj.setProcessBackfaces(true);
					MovementTransform move = new MovementTransform(new Vector(cam.getForward().x, cam.getForward().y, cam.getForward().z), 15);
					move.moveUntil(t -> t.getDistanceMoved() >= 1000);
					proj.addTransform(move);
					proj.registerPlugin(Events.CHECK_COLLISION, Utils.hasCollided(getObjects, explode, explode), true);
					
					Point pos = new Point(cam.getPosition());
					Vector right = cam.getRight();
					//offsets to the right of the camera
					pos.x += right.x * 25;
					pos.y += right.y * 25;
					pos.z += right.z * 25;
					cnv.registerObject(proj, pos, false);
					ObjectTiedLightSource l5 = new ObjectTiedLightSource(pos.x, pos.y, pos.z);
					l5.tieTo(proj);
					l5.setColour(new Color(0, 255, 0));
					l5.setRange(300);
					cnv.addLightSource(l5);
				}
				
				if (key.getKeyChar() == 'b'){
					Sphere proj = new Sphere(18,20);
					proj.setBaseIntensity(1);
					proj.setColour(new Color(0, 255, 255, 80));
					
					proj.deleteAfterTransforms();
					proj.setProcessBackfaces(true);
					MovementTransform move = new MovementTransform(new Vector(cam.getForward().x, cam.getForward().y, cam.getForward().z), 15);
					move.moveUntil(t -> t.getDistanceMoved() >= 1000);
					proj.addTransform(move);

					proj.registerPlugin(Events.CHECK_COLLISION, bounce, true);
					
					Point pos = new Point(cam.getPosition());
					Vector right = cam.getRight();
					//offsets to the left of the camera
					pos.x -= right.x * 25;
					pos.y -= right.y * 25;
					pos.z -= right.z * 25;
					cnv.registerObject(proj, pos, false);
					ObjectTiedLightSource l5 = new ObjectTiedLightSource(pos.x, pos.y, pos.z);
					l5.tieTo(proj);
					l5.setColour(new Color(0, 255, 255));
					l5.setRange(300);
					cnv.addLightSource(l5);
				}
			}
			
		});
		
		scnv.setVisible(true);
		cnv.setVisible(true);
		this.requestFocus();
		this.canvas = cnv;

	}
	
	public void drawCycle()
	{
		long sleep = 75;
		while (go){

			try {
				//System.out.println(sleep);
				if (sleep > 0) Thread.sleep(sleep);
				else Thread.sleep(1);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			long cycleStart = new Date().getTime();
			canvas.doDraw();
			sleep = 75 - (new Date().getTime() - cycleStart);
		}
		
		System.exit(0);
	}
	
	@Override
	public void dispose(){
		super.dispose();
		slave.dispose();
		go = false;	
	}
}
