package com.graphics.tests;

public class Events {
	public static final String CHECK_COLLISION = "check_collision";
	public static final String EXPLODE = "explode";
	public static final String COLLISION_IMPACTOR = "collision_impactor";
	public static final String COLLISION_IMPACTEE = "collision_impactee";
}
