package com.graphics.tests;

import java.awt.Color;
import java.awt.Graphics;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.function.BiConsumer;
import java.util.stream.Collectors;

import com.graphics.lib.Canvas3D;
import com.graphics.lib.CanvasObject;
import com.graphics.lib.Facet;
import com.graphics.lib.LightSource;
import com.graphics.lib.Plugin;
import com.graphics.lib.Point;
import com.graphics.lib.Vector;
import com.graphics.lib.WorldCoord;
import com.graphics.lib.transform.MovementTransform;
import com.graphics.lib.transform.RepeatingTransform;
import com.graphics.lib.transform.Rotation;
import com.graphics.lib.transform.YRotation;
import com.graphics.lib.transform.XRotation;

public class Utils {
	
	public static Plugin<CanvasObject, Set<CanvasObject>> explode(List<LightSource> lightSources) 
	{
		return (obj) -> {
		Set<CanvasObject> children = new HashSet<CanvasObject>();
		
		for (Facet f : obj.getFacetList())
		{
			CanvasObject fragment = new CanvasObject();
			fragment.getVertexList().add(new WorldCoord(f.point1.x, f.point1.y, f.point1.z));
			fragment.getVertexList().add(new WorldCoord(f.point2.x, f.point2.y, f.point2.z));
			fragment.getVertexList().add(new WorldCoord(f.point3.x, f.point3.y, f.point3.z));
			fragment.getFacetList().add(new Facet(fragment.getVertexList().get(0), fragment.getVertexList().get(1), fragment.getVertexList().get(2)));
			fragment.setProcessBackfaces(true);
			fragment.setColour(f.getColour() != null ? f.getColour() : obj.getColour());
			fragment.addTransform(new MovementTransform(fragment.getFacetList().get(0).getNormal(), Math.random() * 15 + 1 ));
			fragment.addTransformAboutCentre(new RepeatingTransform<Rotation<?>>(new Rotation<YRotation>(YRotation.class, Math.random() * 10), -1), new RepeatingTransform<Rotation<?>>(new Rotation<XRotation>(XRotation.class, Math.random() * 10), -1));
			children.add(fragment);
		}
		LightSource flash = new LightSource(obj.getCentre().x,  obj.getCentre().y, obj.getCentre().z);
		flash.setRange(-1);
		lightSources.add(flash);
		obj.getChildren().addAll(children);
		
		obj.setVisible(false);
		obj.cancelTransforms();
		obj.removePlugins();
		new Thread(() -> {
			try {
				for (int i = 0 ; i < 15 ; i++)
				{
					Thread.sleep(200);
					flash.setIntensity(flash.getIntensity() - 0.075);
				}
			} catch (Exception e) {}
			flash.setDeleted(true);
		}).start();
		return children;
		};
	}
	
	public static Plugin<CanvasObject,CanvasObject> hasCollided(Plugin<?,Set<CanvasObject>> objects, Plugin<CanvasObject, ?> impactorPlugin, Plugin<CanvasObject, ?> impacteePlugin)
	{
		return (obj) -> {
			CanvasObject inCollision = (CanvasObject)obj.executePlugin("IN_COLLISION"); //may need to be a list - may hit more than one!
			
			for (CanvasObject impactee : objects.execute(null)){
				if (impactee == obj) continue;
				if (obj.getVertexList().stream().anyMatch(p -> impactee.isPointInside(p)))
				{
					if (inCollision == impactee) { return null;}
					if (impactorPlugin != null) impactorPlugin.execute(obj);
					if (impacteePlugin != null) impacteePlugin.execute(impactee);
					impactee.addObserver(obj);
					obj.registerPlugin("IN_COLLISION", (o) -> {return impactee;}, false);
					return impactee;
				}else if (inCollision == impactee){
					obj.removePlugin("IN_COLLISION");
				}
			}
			return null;
		};
	}
	
	public static Plugin<CanvasObject, Void> onCollision()
	{
		return (obj) -> {
			obj.cancelTransforms();
			obj.removePlugins();
			return null;
		};
	}
	
	public static Plugin<CanvasObject, Void> bounce(CanvasObject impactee)
	{
		return (obj) -> {
			Optional<WorldCoord> impactPoint = obj.getVertexList().stream().filter(p -> impactee.isPointInside(p)).findAny();
			if (!impactPoint.isPresent()) return null;
			
			List<MovementTransform> mTrans = obj.getTransformsOfType(MovementTransform.class);
			if (mTrans.size() == 0) return null;
			
			Vector move = mTrans.get(0).getVector(); //just getting the first one for now (if there is more than one) 
			double velocity = mTrans.get(0).getVelocity(); 
			Point prevPoint = new Point(impactPoint.get().x - (move.x * velocity), impactPoint.get().y - (move.y * velocity), impactPoint.get().z - (move.z * velocity));
			Facet curFacet = null;
			double curDist = -1;
			for(Facet f : impactee.getFacetList().stream().filter(f -> f.getDistanceFromFacetPlane(impactPoint.get()) < velocity + 1).collect(Collectors.toList()))
			{
				Point intersect = f.getIntersectionPointWithFacetPlane(prevPoint, move);

				//if intersected with plane of facet check we are within the bounds of the facet
				if (intersect != null && (prevPoint.distanceTo(intersect) < curDist || curDist == -1 ) && f.isPointWithin(intersect)){
					curFacet = f;
					curDist = prevPoint.distanceTo(intersect);
				}
			}
			/*for(Facet f : impactee.getFacetList()){
				double dist = f.getDistanceFromFacetPlane(impactPoint.get());		
				if (dist < velocity + 1){
					Point intersect = f.getIntersectionPointWithFacetPlane(prevPoint, move);
					if (intersect == null || prevPoint.distanceTo(intersect) > velocity) continue;
					//if intersected with plane of facet check we are within the bounds of the facet
					if (f.isPointWithin(intersect)){
						curFacet = f;
						curDist = prevPoint.distanceTo(intersect)
						break;
					}
				}
			}
			System.out.println("------");*/
			
			if (curFacet == null) return null;
			Vector impactedNormal = curFacet.getNormal();
			
			//I know r=d-2(d.n)n is reflection vector in 2 dimension (hopefully it'll work on 3)
			
			double multiplier = move.dotProduct(impactedNormal) * -2;
			move.x += (impactedNormal.x * multiplier);
			move.y += (impactedNormal.y * multiplier);
			move.z += (impactedNormal.z * multiplier);
			
			return null;
		};
	}
	
	public static BiConsumer<Canvas3D,Graphics> showMarkers(){
		return (c, g) -> {
			double pixelsPerDegree = (double)c.getHeight() / 180;
			int middle = c.getHeight() / 2;
			g.setColor(new Color(0,0,0,150));
			g.fillRect(0, 0, 35, c.getHeight());
			g.setColor(Color.WHITE);
			double pitch = c.getCamera().getPitch();
			for (int i = 0 ; i < 181 ; i+=10){
				double marker = i - 90;
				double offset = marker + pitch;
				if (offset > 90 || offset < -90) continue;
				int pos = middle - (int)Math.round((offset*pixelsPerDegree)); 
				g.drawLine(5,pos,30,pos);
				g.drawString(""+(int)marker, 10, pos-1);
			}
			g.setColor(Color.RED);
			g.drawLine(5,middle,30,middle);
			
			
			pixelsPerDegree = (double)c.getWidth() / 180;
			middle = c.getWidth() / 2;
			g.setColor(new Color(0,0,0,150));
			g.fillRect(0, 0, c.getWidth(), 35);
			g.setColor(Color.WHITE);
			double bearing = c.getCamera().getBearing();
			int start = (int)((bearing - 90)/10) * 10;
			for (int i = 0 ; i < 181 ; i+=10){
				double marker = start + i;
				double offset = marker - bearing;
				int pos = middle + (int)Math.round((offset*pixelsPerDegree)); 
				if (marker < -179){
					marker = 180 + (180 + marker);
				}
				else if (marker > 180){
					marker = -180 + (marker - 180);
				}
				g.drawLine(pos,5,pos,30);
				g.drawString(""+(int)marker, pos+1, 20);
			}
			g.setColor(Color.RED);
			g.drawLine(middle,5,middle,30);
		};
	}
	
}
